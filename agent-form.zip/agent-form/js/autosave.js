/**
 * Auto-save
 * Periodically saves form data to localStorage
 */

const AutoSave = (() => {
  'use strict';

  const STORAGE_KEY = 'agent-form-draft';
  const SAVE_INTERVAL = 5000; // 5 seconds
  let saveTimer = null;
  let lastSavedData = null;

  /**
   * Initialize auto-save
   */
  function init() {
    // Restore saved data
    restore();

    // Set up periodic save
    startAutoSave();

    // Save on page unload
    window.addEventListener('beforeunload', save);

    // Keyboard shortcut: Ctrl+S / Cmd+S
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        save();
        Utils.showToast('草稿已保存');
      }
    });

    // Bind save draft button
    const saveBtn = document.getElementById('saveDraftBtn');
    if (saveBtn) {
      saveBtn.addEventListener('click', () => {
        save();
        Utils.showToast('草稿已保存');
      });
    }
  }

  /**
   * Save current form data to localStorage
   */
  function save() {
    const data = Validator.getData();
    const tags = getSelectedTags();

    const saveData = {
      ...data,
      tags,
      timestamp: Date.now()
    };

    // Only save if data has changed
    if (JSON.stringify(saveData) === JSON.stringify(lastSavedData)) return;

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(saveData));
      lastSavedData = saveData;
    } catch (e) {
      console.warn('Auto-save failed:', e);
    }
  }

  /**
   * Restore form data from localStorage
   */
  function restore() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) return;

      const data = JSON.parse(saved);

      // Restore textarea values
      Object.keys(data).forEach(key => {
        if (key === 'tags' || key === 'timestamp') return;
        const input = document.getElementById(key);
        if (input && data[key]) {
          input.value = data[key];
          input.dispatchEvent(new Event('input'));
        }
      });

      // Restore tags
      if (data.tags && Array.isArray(data.tags)) {
        data.tags.forEach(tagName => {
          const tag = document.querySelector(`.tag[data-tag="${tagName}"]`);
          if (tag) tag.classList.add('active');
        });
      }

      lastSavedData = data;

      // Show restore notification
      if (data.timestamp) {
        const timeAgo = getTimeAgo(data.timestamp);
        Utils.showToast(`已恢复草稿（${timeAgo}前保存）`);
      }
    } catch (e) {
      console.warn('Restore failed:', e);
    }
  }

  /**
   * Get selected tags
   */
  function getSelectedTags() {
    const tags = document.querySelectorAll('.tag.active');
    return [...tags].map(tag => tag.dataset.tag);
  }

  /**
   * Start periodic auto-save
   */
  function startAutoSave() {
    stopAutoSave();
    saveTimer = setInterval(save, SAVE_INTERVAL);
  }

  /**
   * Stop periodic auto-save
   */
  function stopAutoSave() {
    if (saveTimer) {
      clearInterval(saveTimer);
      saveTimer = null;
    }
  }

  /**
   * Clear saved data
   */
  function clear() {
    localStorage.removeItem(STORAGE_KEY);
    lastSavedData = null;
  }

  /**
   * Format time ago
   */
  function getTimeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);

    if (seconds < 60) return '刚刚';
    if (seconds < 3600) return `${Math.floor(seconds / 60)} 分钟`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)} 小时`;
    return `${Math.floor(seconds / 86400)} 天`;
  }

  return { init, save, restore, clear };
})();

window.AutoSave = AutoSave;
