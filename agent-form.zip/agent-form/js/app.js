/**
 * Main Application
 * Initializes all modules and binds top-level events
 */

(() => {
  'use strict';

  const { $, $$, showToast } = Utils;

  /**
   * Initialize the application
   */
  function init() {
    // Initialize modules
    ThemeManager.init();
    Validator.init();
    AutoSave.init();

    // Bind UI events
    bindExampleBlock();
    bindTags();
    bindButtons();
    bindStepIndicator();

    // Scroll animations
    initScrollAnimations();
  }

  /**
   * Bind example block click
   */
  function bindExampleBlock() {
    const exampleBlock = $('#exampleBlock');
    const contentInput = $('#contentInput');
    if (!exampleBlock || !contentInput) return;

    const exampleText = '我构建了一个基于 OpenClaw 的自动化代码库重构 Agent。它能自动扫描存量代码中的技术债，根据最新的架构规范生成重构 PR，并自动运行单元测试进行闭环验证。目前已在公司 20 人的后端团队落地，每日消耗约 500 万 Token，将代码规范评估的效率提升了 80%。';

    function fillExample() {
      if (contentInput.value.length > 0) {
        contentInput.value = contentInput.value + '\n\n' + exampleText;
      } else {
        contentInput.value = exampleText;
      }
      contentInput.focus();
      contentInput.dispatchEvent(new Event('input'));

      // Animate
      exampleBlock.style.opacity = '0.4';
      exampleBlock.style.transform = 'scale(0.98)';
      setTimeout(() => {
        exampleBlock.style.opacity = '1';
        exampleBlock.style.transform = 'scale(1)';
      }, 300);
    }

    exampleBlock.addEventListener('click', fillExample);
    exampleBlock.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        fillExample();
      }
    });
  }

  /**
   * Bind tag selection
   */
  function bindTags() {
    const tags = $$('.tag');
    tags.forEach(tag => {
      tag.addEventListener('click', () => {
        tag.classList.toggle('active');

        // Toggle the icon between + and ✓
        const svg = tag.querySelector('svg');
        if (svg) {
          if (tag.classList.contains('active')) {
            svg.innerHTML = '<polyline points="20 6 9 17 4 12"/>';
          } else {
            svg.innerHTML = '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>';
          }
        }
      });
    });
  }

  /**
   * Bind action buttons
   */
  function bindButtons() {
    // Clear button
    const clearBtn = $('#clearBtn');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        const contentInput = $('#contentInput');
        if (contentInput && contentInput.value.length === 0) return;

        Validator.clearAll();

        // Reset tags
        $$('.tag.active').forEach(tag => {
          tag.classList.remove('active');
          const svg = tag.querySelector('svg');
          if (svg) {
            svg.innerHTML = '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>';
          }
        });

        AutoSave.clear();
        showToast('内容已清空');
      });
    }

    // Submit button
    const submitBtn = $('#submitBtn');
    if (submitBtn) {
      submitBtn.addEventListener('click', () => {
        if (!Validator.isValid()) return;

        // Collect all data
        const data = Validator.getData();
        const tags = [...$$('.tag.active')].map(t => t.dataset.tag);

        console.log('Form submitted:', { ...data, tags });
        showToast('提交成功！感谢你的详细描述');

        // Disable button temporarily
        submitBtn.disabled = true;
        submitBtn.textContent = '已提交';
        setTimeout(() => {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '提交 <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>';
        }, 3000);
      });
    }

    // Previous button
    const prevBtn = $('#prevBtn');
    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        showToast('上一步功能待实现');
      });
    }
  }

  /**
   * Bind step indicator clicks
   */
  function bindStepIndicator() {
    const steps = $$('.step-item');
    steps.forEach(step => {
      step.addEventListener('click', () => {
        const stepNum = step.dataset.step;
        if (stepNum === '4') {
          showToast('你当前正在此步骤');
        } else {
          showToast(`第 ${stepNum} 步功能待实现`);
        }
      });
    });
  }

  /**
   * Initialize scroll-triggered animations
   */
  function initScrollAnimations() {
    const animatedElements = $$('[data-animate]');

    if (!('IntersectionObserver' in window)) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.animationPlayState = 'running';
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    });

    animatedElements.forEach(el => {
      el.style.animationPlayState = 'paused';
      observer.observe(el);
    });

    // Immediately play elements already in viewport
    setTimeout(() => {
      animatedElements.forEach(el => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight) {
          el.style.animationPlayState = 'running';
        }
      });
    }, 100);
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
