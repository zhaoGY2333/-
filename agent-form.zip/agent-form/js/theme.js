/**
 * Theme Toggle
 * Handles light/dark mode switching with localStorage persistence
 */

const ThemeManager = (() => {
  'use strict';

  const STORAGE_KEY = 'agent-form-theme';
  let currentTheme = 'light';

  /**
   * Initialize theme
   */
  function init() {
    // Check localStorage first, then system preference
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      currentTheme = saved;
    } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      currentTheme = 'dark';
    }

    applyTheme(currentTheme);
    bindEvents();
  }

  /**
   * Apply theme to document
   */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    currentTheme = theme;

    // Update meta theme-color
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      meta.content = theme === 'dark' ? '#1A1A1E' : '#F6F5F0';
    }
  }

  /**
   * Toggle between light and dark
   */
  function toggle() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(currentTheme);
    localStorage.setItem(STORAGE_KEY, currentTheme);
  }

  /**
   * Bind toggle button event
   */
  function bindEvents() {
    const toggleBtn = document.getElementById('themeToggle');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', toggle);
    }

    // Listen for system theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      if (!localStorage.getItem(STORAGE_KEY)) {
        applyTheme(e.matches ? 'dark' : 'light');
      }
    });
  }

  /**
   * Get current theme
   */
  function getTheme() {
    return currentTheme;
  }

  return { init, toggle, getTheme };
})();

window.ThemeManager = ThemeManager;
