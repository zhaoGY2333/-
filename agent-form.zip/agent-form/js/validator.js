/**
 * Form Validator
 * Handles character counting, validation messages, and submit state
 */

const Validator = (() => {
  'use strict';

  const { $, formatNumber } = Utils;

  // Field configurations
  const fields = [
    {
      id: 'painPointInput',
      counterId: 'painPointCount',
      validationId: 'painPointValidation',
      max: 500,
      min: 50,
      minLabel: '50'
    },
    {
      id: 'logicInput',
      counterId: 'logicCount',
      validationId: 'logicValidation',
      max: 800,
      min: 80,
      minLabel: '80'
    },
    {
      id: 'contentInput',
      counterId: 'charCount',
      validationId: 'validationMsg',
      max: 1200,
      min: 100,
      minLabel: '100'
    }
  ];

  // Track field states
  const states = {};

  /**
   * Initialize all validators
   */
  function init() {
    fields.forEach(field => {
      const input = $(`#${field.id}`);
      if (!input) return;

      states[field.id] = { length: 0, valid: false };

      input.addEventListener('input', () => {
        handleInput(field, input);
        updateProgress();
        updateSubmitButton();
      });
    });
  }

  /**
   * Handle input for a specific field
   */
  function handleInput(field, input) {
    const len = input.value.length;
    states[field.id].length = len;

    // Update character counter
    updateCounter(field.counterId, len, field.max);

    // Update validation
    if (len > 0 && len < field.min) {
      showValidation(field.validationId, 'error',
        `还需至少 ${field.min - len} 个字符才能提交`);
      states[field.id].valid = false;
    } else if (len >= field.min) {
      showValidation(field.validationId, 'success', '内容长度符合要求');
      states[field.id].valid = true;
    } else {
      hideValidation(field.validationId);
      states[field.id].valid = false;
    }

    // Auto-resize
    const minHeight = field.id === 'contentInput' ? 220 : 140;
    Utils.autoResize(input, minHeight);
  }

  /**
   * Update character counter display
   */
  function updateCounter(counterId, current, max) {
    const counter = $(`#${counterId}`);
    if (!counter) return;

    const currentEl = counter.querySelector('.current');
    if (currentEl) {
      currentEl.textContent = formatNumber(current);
    }

    counter.classList.remove('warning', 'danger');
    if (current > max * 0.9) {
      counter.classList.add('danger');
    } else if (current > max * 0.75) {
      counter.classList.add('warning');
    }
  }

  /**
   * Show validation message
   */
  function showValidation(id, type, message) {
    const el = $(`#${id}`);
    if (!el) return;

    el.className = `validation-msg visible ${type}`;

    const iconSvg = type === 'error'
      ? '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>'
      : '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>';

    el.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${iconSvg}</svg>
      <span>${message}</span>
    `;
  }

  /**
   * Hide validation message
   */
  function hideValidation(id) {
    const el = $(`#${id}`);
    if (!el) return;
    el.classList.remove('visible');
  }

  /**
   * Update progress bar
   */
  function updateProgress() {
    const progressBar = $('#progressBar');
    if (!progressBar) return;

    // Calculate total progress based on all fields
    let totalProgress = 0;
    fields.forEach(field => {
      const state = states[field.id];
      if (state) {
        totalProgress += Math.min(state.length / field.min, 1);
      }
    });

    const percentage = (totalProgress / fields.length) * 100;
    progressBar.style.width = Math.min(percentage, 100) + '%';
  }

  /**
   * Update submit button state
   */
  function updateSubmitButton() {
    const submitBtn = $('#submitBtn');
    if (!submitBtn) return;

    const allValid = fields.every(field => states[field.id]?.valid);
    submitBtn.disabled = !allValid;
  }

  /**
   * Check if form is valid
   */
  function isValid() {
    return fields.every(field => states[field.id]?.valid);
  }

  /**
   * Get form data
   */
  function getData() {
    const data = {};
    fields.forEach(field => {
      const input = $(`#${field.id}`);
      if (input) {
        data[field.id] = input.value;
      }
    });
    return data;
  }

  /**
   * Clear all fields
   */
  function clearAll() {
    fields.forEach(field => {
      const input = $(`#${field.id}`);
      if (input) {
        input.value = '';
        handleInput(field, input);
      }
    });
    updateProgress();
    updateSubmitButton();
  }

  return { init, isValid, getData, clearAll, states };
})();

window.Validator = Validator;
