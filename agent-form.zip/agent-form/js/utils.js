/**
 * Utility Functions
 * Common helpers used across the application
 */

const Utils = (() => {
  'use strict';

  /**
   * Select a single DOM element
   */
  const $ = (selector, parent = document) => parent.querySelector(selector);

  /**
   * Select multiple DOM elements
   */
  const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];

  /**
   * Debounce function
   */
  const debounce = (fn, delay = 300) => {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  };

  /**
   * Throttle function
   */
  const throttle = (fn, limit = 100) => {
    let inThrottle;
    return (...args) => {
      if (!inThrottle) {
        fn.apply(this, args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  };

  /**
   * Format number with commas
   */
  const formatNumber = (num) => {
    return num.toLocaleString('zh-CN');
  };

  /**
   * Show toast notification
   */
  let toastTimer;
  const showToast = (message, duration = 3000) => {
    const toast = $('#toast');
    const toastText = $('#toastText');
    if (!toast || !toastText) return;

    clearTimeout(toastTimer);
    toastText.textContent = message;
    toast.classList.add('show');

    toastTimer = setTimeout(() => {
      toast.classList.remove('show');
    }, duration);
  };

  /**
   * Auto-resize textarea
   */
  const autoResize = (textarea, minHeight = 140) => {
    if (!textarea) return;
    textarea.style.height = 'auto';
    const newHeight = Math.max(minHeight, textarea.scrollHeight);
    textarea.style.height = newHeight + 'px';
  };

  /**
   * Clamp a value between min and max
   */
  const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

  /**
   * Simple event emitter
   */
  const createEmitter = () => {
    const listeners = {};
    return {
      on(event, fn) {
        (listeners[event] = listeners[event] || []).push(fn);
        return this;
      },
      emit(event, ...args) {
        (listeners[event] || []).forEach(fn => fn(...args));
      },
      off(event, fn) {
        listeners[event] = (listeners[event] || []).filter(f => f !== fn);
        return this;
      }
    };
  };

  return { $, $$, debounce, throttle, formatNumber, showToast, autoResize, clamp, createEmitter };
})();

// Export for use in other modules
window.Utils = Utils;
