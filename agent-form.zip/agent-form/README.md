# Agent 申请表

一个精致的、零依赖的 Agent 成果描述表单页面，适用于 AI/Agent 项目申请和评估场景。

## 功能特性

- **多字段表单**：核心痛点、核心逻辑流、综合成果描述三个子表单
- **实时字数统计**：每个输入框独立计数，接近上限变色提醒
- **智能验证**：最低字数要求、实时验证反馈
- **标签选择**：预设技术标签（长链推理、多 Agent 协作、RAG 等），点击切换
- **示例填入**：点击示例区块自动填入参考内容
- **深色模式**：支持系统偏好自动切换 + 手动切换，localStorage 持久化
- **自动保存**：每 5 秒自动保存草稿到 localStorage，支持 Ctrl+S 手动保存
- **草稿恢复**：页面加载时自动恢复上次编辑内容
- **进度条**：顶部渐变进度条，根据填写进度动态更新
- **步骤指示器**：5 步流程导航，当前步骤高亮
- **响应式设计**：完美适配桌面、平板、手机
- **打印优化**：打印时隐藏导航和操作按钮
- **无障碍**：ARIA 标签、键盘导航、`prefers-reduced-motion` 支持
- **滚动动画**：IntersectionObserver 驱动的入场动画

## 项目结构

```
agent-form/
├── index.html              # 主页面
├── css/
│   ├── variables.css       # CSS 变量和设计令牌
│   ├── base.css            # 基础样式和重置
│   ├── layout.css          # 布局（导航、步骤指示器、页脚）
│   ├── components.css      # 组件（卡片、按钮、标签、Toast）
│   ├── form.css            # 表单元素（输入框、计数器、验证）
│   ├── animations.css      # 动画和过渡效果
│   ├── responsive.css      # 响应式断点
│   └── dark-theme.css      # 深色主题
├── js/
│   ├── utils.js            # 工具函数
│   ├── validator.js        # 表单验证逻辑
│   ├── theme.js            # 主题切换管理
│   ├── autosave.js         # 自动保存和草稿恢复
│   └── app.js              # 主应用入口
└── assets/                 # 静态资源目录（预留）
```

## 快速开始

### 方式一：直接打开

双击 `index.html` 即可在浏览器中打开。

### 方式二：本地服务器

```bash
# Python
python3 -m http.server 8080

# Node.js
npx serve .

# PHP
php -S localhost:8080
```

### 方式三：GitHub Pages

1. 将项目推送到 GitHub 仓库
2. 进入 Settings → Pages
3. Source 选择 `main` 分支，目录选 `/ (root)`
4. 保存后等待部署完成

## 技术栈

- **HTML5** - 语义化标签
- **CSS3** - 自定义属性、Flexbox、Grid、媒体查询
- **Vanilla JavaScript** - 零依赖，原生 ES6+ 模块模式
- **Google Fonts** - Noto Serif SC + Noto Sans SC

## 浏览器兼容

| 浏览器 | 版本 |
|--------|------|
| Chrome | 80+ |
| Firefox | 78+ |
| Safari | 14+ |
| Edge | 80+ |

## 自定义

### 修改主题色

编辑 `css/variables.css` 中的 CSS 变量：

```css
:root {
  --accent-blue: #2B6CB0;     /* 主色调 */
  --accent-gold: #C4943A;     /* 强调色 */
  --accent-red: #E8453C;      /* 错误/必填 */
  --accent-green: #2D8A56;    /* 成功 */
}
```

### 修改字数限制

编辑 `js/validator.js` 中的 `fields` 配置：

```js
const fields = [
  { id: 'contentInput', max: 1200, min: 100, ... }
];
```

## License

MIT
